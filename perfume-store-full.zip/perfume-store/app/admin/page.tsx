import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { formatCurrency } from "@/lib/utils";

async function getStats() {
  const [totalUsers, totalProducts, totalOrders, pendingOrders, paidAgg, recentOrders, lowStock] = await Promise.all([
    prisma.user.count({ where: { role: "CUSTOMER" } }),
    prisma.product.count(),
    prisma.order.count(),
    prisma.order.count({ where: { orderStatus: "PENDING" } }),
    prisma.order.aggregate({ where: { paymentStatus: "PAID" }, _sum: { total: true } }),
    prisma.order.findMany({ orderBy: { createdAt: "desc" }, take: 6 }),
    prisma.product.findMany({ where: { stock: { lte: 10 }, isActive: true }, orderBy: { stock: "asc" }, take: 5 }),
  ]);
  return { totalUsers, totalProducts, totalOrders, pendingOrders, totalSales: paidAgg._sum.total || 0, recentOrders, lowStock };
}

export default async function AdminDashboardPage() {
  const stats = await getStats();

  const cards = [
    { label: "Total Sales", value: formatCurrency(stats.totalSales) },
    { label: "Total Orders", value: stats.totalOrders },
    { label: "Pending Orders", value: stats.pendingOrders },
    { label: "Total Products", value: stats.totalProducts },
    { label: "Total Customers", value: stats.totalUsers },
  ];

  return (
    <div className="space-y-8">
      <h1 className="font-serif text-3xl text-charcoal">Dashboard</h1>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
        {cards.map((c) => (
          <div key={c.label} className="rounded-sm border border-neutral-200 bg-white p-5">
            <p className="text-xs uppercase tracking-wide text-neutral-500">{c.label}</p>
            <p className="mt-2 text-2xl font-semibold text-charcoal">{c.value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-sm border border-neutral-200 bg-white p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-serif text-lg text-charcoal">Recent Orders</h2>
            <Link href="/admin/orders" className="text-sm text-gold hover:underline">View All →</Link>
          </div>
          <div className="space-y-2">
            {stats.recentOrders.map((o) => (
              <Link key={o.id} href={`/admin/orders/${o.id}`} className="flex justify-between rounded-sm border border-neutral-100 p-3 text-sm hover:border-gold">
                <span>{o.orderNumber}</span>
                <span className="text-neutral-500">{o.orderStatus}</span>
                <span className="font-medium">{formatCurrency(o.total)}</span>
              </Link>
            ))}
          </div>
        </div>

        <div className="rounded-sm border border-neutral-200 bg-white p-6">
          <h2 className="mb-4 font-serif text-lg text-charcoal">Low Stock Products</h2>
          {stats.lowStock.length === 0 ? (
            <p className="text-sm text-neutral-500">No low-stock products.</p>
          ) : (
            <div className="space-y-2">
              {stats.lowStock.map((p) => (
                <Link key={p.id} href={`/admin/products/${p.id}/edit`} className="flex justify-between rounded-sm border border-neutral-100 p-3 text-sm hover:border-gold">
                  <span>{p.name}</span>
                  <span className="font-medium text-red-600">{p.stock} left</span>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
