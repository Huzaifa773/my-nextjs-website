import Link from "next/link";
import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { LayoutDashboard, Package, FolderTree, Users, ShoppingCart, CreditCard, ArrowLeft } from "lucide-react";
import { authOptions } from "@/lib/auth";

const NAV_ITEMS = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/categories", label: "Categories", icon: FolderTree },
  { href: "/admin/orders", label: "Orders", icon: ShoppingCart },
  { href: "/admin/payments", label: "Payments", icon: CreditCard },
  { href: "/admin/users", label: "Users", icon: Users },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  // Defense in depth: middleware.ts already blocks non-admins from /admin/*,
  // but we double-check here in case middleware is ever bypassed or changed.
  const session = await getServerSession(authOptions);
  if (!session?.user || session.user.role !== "ADMIN") {
    redirect("/login");
  }

  return (
    <div className="flex min-h-screen bg-neutral-50">
      <aside className="w-64 flex-shrink-0 bg-charcoal text-ivory">
        <div className="border-b border-charcoal-medium px-6 py-5">
          <p className="font-serif text-lg text-gold">MAISON CHARCOAL</p>
          <p className="text-xs text-neutral-400">Admin Panel</p>
        </div>
        <nav className="space-y-1 p-3">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 rounded-sm px-3 py-2 text-sm hover:bg-charcoal-light hover:text-gold"
            >
              <item.icon size={16} /> {item.label}
            </Link>
          ))}
          <Link href="/" className="mt-4 flex items-center gap-3 rounded-sm px-3 py-2 text-sm text-neutral-400 hover:bg-charcoal-light hover:text-gold">
            <ArrowLeft size={16} /> Back to Store
          </Link>
        </nav>
      </aside>
      <main className="flex-1 overflow-x-auto p-8">{children}</main>
    </div>
  );
}
