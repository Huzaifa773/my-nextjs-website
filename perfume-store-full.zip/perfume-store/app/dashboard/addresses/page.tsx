import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { AddressManager } from "@/components/AddressManager";

export default async function DashboardAddressesPage() {
  const session = await getServerSession(authOptions);
  const addresses = await prisma.address.findMany({
    where: { userId: session!.user.id },
    orderBy: [{ isDefault: "desc" }, { createdAt: "desc" }],
  });

  return (
    <div className="rounded-sm border border-neutral-200 p-6">
      <h2 className="mb-4 font-serif text-xl text-charcoal">My Addresses</h2>
      <AddressManager initialAddresses={addresses} />
    </div>
  );
}
