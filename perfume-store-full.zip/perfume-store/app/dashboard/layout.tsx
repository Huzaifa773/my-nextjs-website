import Link from "next/link";
import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { User, Package, Heart, MapPin, Settings } from "lucide-react";
import { authOptions } from "@/lib/auth";

const NAV_ITEMS = [
  { href: "/dashboard", label: "Overview", icon: User },
  { href: "/dashboard/orders", label: "My Orders", icon: Package },
  { href: "/wishlist", label: "Wishlist", icon: Heart },
  { href: "/dashboard/addresses", label: "Addresses", icon: MapPin },
  { href: "/dashboard/settings", label: "Account Settings", icon: Settings },
];

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login?callbackUrl=/dashboard");

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 md:px-8">
      <h1 className="section-title mb-8">My Account</h1>
      <div className="grid gap-8 md:grid-cols-4">
        <aside className="md:col-span-1">
          <nav className="space-y-1 rounded-sm border border-neutral-200 p-2">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 rounded-sm px-3 py-2 text-sm text-neutral-700 hover:bg-champagne/40 hover:text-charcoal"
              >
                <item.icon size={16} /> {item.label}
              </Link>
            ))}
          </nav>
        </aside>
        <div className="md:col-span-3">{children}</div>
      </div>
    </div>
  );
}
