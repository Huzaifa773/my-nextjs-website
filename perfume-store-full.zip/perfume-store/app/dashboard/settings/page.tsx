import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { SettingsForm } from "@/components/SettingsForm";

export default async function DashboardSettingsPage() {
  const session = await getServerSession(authOptions);
  const user = await prisma.user.findUnique({ where: { id: session!.user.id } });

  return (
    <div className="rounded-sm border border-neutral-200 p-6">
      <h2 className="mb-4 font-serif text-xl text-charcoal">Account Settings</h2>
      <SettingsForm initialName={user!.name} initialPhone={user!.phone || ""} email={user!.email} />
    </div>
  );
}
