import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatCurrency } from "@/lib/utils";

export default async function DashboardOverviewPage() {
  const session = await getServerSession(authOptions);
  const user = await prisma.user.findUnique({ where: { id: session!.user.id } });
  const recentOrders = await prisma.order.findMany({
    where: { userId: session!.user.id },
    orderBy: { createdAt: "desc" },
    take: 5,
  });

  return (
    <div className="space-y-8">
      <div className="rounded-sm border border-neutral-200 p-6">
        <h2 className="mb-4 font-serif text-xl text-charcoal">Profile</h2>
        <dl className="grid grid-cols-2 gap-y-2 text-sm">
          <dt className="text-neutral-500">Name</dt><dd>{user?.name}</dd>
          <dt className="text-neutral-500">Email</dt><dd>{user?.email}</dd>
          <dt className="text-neutral-500">Phone</dt><dd>{user?.phone || "—"}</dd>
        </dl>
        <Link href="/dashboard/settings" className="mt-4 inline-block text-sm text-gold hover:underline">
          Edit Profile →
        </Link>
      </div>

      <div className="rounded-sm border border-neutral-200 p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-serif text-xl text-charcoal">Recent Orders</h2>
          <Link href="/dashboard/orders" className="text-sm text-gold hover:underline">View All →</Link>
        </div>
        {recentOrders.length === 0 ? (
          <p className="text-sm text-neutral-500">You haven't placed any orders yet.</p>
        ) : (
          <div className="space-y-3">
            {recentOrders.map((o) => (
              <Link
                key={o.id}
                href={`/order-confirmation/${o.id}`}
                className="flex items-center justify-between rounded-sm border border-neutral-100 p-3 text-sm hover:border-gold"
              >
                <div>
                  <p className="font-medium text-charcoal">{o.orderNumber}</p>
                  <p className="text-xs text-neutral-500">{new Date(o.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-charcoal">{formatCurrency(o.total)}</p>
                  <p className="text-xs text-neutral-500">{o.orderStatus}</p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
