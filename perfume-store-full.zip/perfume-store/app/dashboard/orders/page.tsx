import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatCurrency } from "@/lib/utils";

const STATUS_COLORS: Record<string, string> = {
  PENDING: "bg-neutral-100 text-neutral-700",
  CONFIRMED: "bg-blue-100 text-blue-700",
  PROCESSING: "bg-amber-100 text-amber-700",
  SHIPPED: "bg-purple-100 text-purple-700",
  DELIVERED: "bg-green-100 text-green-700",
  CANCELLED: "bg-red-100 text-red-700",
};

export default async function DashboardOrdersPage() {
  const session = await getServerSession(authOptions);
  const orders = await prisma.order.findMany({
    where: { userId: session!.user.id },
    include: { items: true },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="rounded-sm border border-neutral-200 p-6">
      <h2 className="mb-4 font-serif text-xl text-charcoal">My Orders</h2>
      {orders.length === 0 ? (
        <p className="text-sm text-neutral-500">You haven't placed any orders yet.</p>
      ) : (
        <div className="space-y-3">
          {orders.map((o) => (
            <Link
              key={o.id}
              href={`/order-confirmation/${o.id}`}
              className="block rounded-sm border border-neutral-100 p-4 hover:border-gold"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-medium text-charcoal">{o.orderNumber}</p>
                  <p className="text-xs text-neutral-500">
                    {new Date(o.createdAt).toLocaleDateString()} · {o.items.length} item(s)
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`rounded-full px-3 py-1 text-xs font-medium ${STATUS_COLORS[o.orderStatus]}`}>
                    {o.orderStatus}
                  </span>
                  <span className="font-medium text-charcoal">{formatCurrency(o.total)}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
