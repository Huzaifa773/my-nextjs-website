"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { signIn } from "next-auth/react";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "", confirm: "" });
  const [loading, setLoading] = useState(false);

  function update(field: string, value: string) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (form.password !== form.confirm) {
      toast.error("Passwords do not match");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          phone: form.phone || undefined,
          password: form.password,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Registration failed");

      const signInRes = await signIn("credentials", {
        email: form.email,
        password: form.password,
        redirect: false,
      });

      if (signInRes?.error) {
        toast.success("Account created. Please log in.");
        router.push("/login");
        return;
      }

      toast.success("Account created successfully!");
      router.push("/dashboard");
      router.refresh();
    } catch (err: any) {
      toast.error(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-4 py-16">
      <h1 className="section-title mb-2 text-center">Create an Account</h1>
      <p className="mb-8 text-center text-sm text-neutral-500">Join Maison Charcoal today</p>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium text-charcoal">Full Name</label>
          <input required value={form.name} onChange={(e) => update("name", e.target.value)} className="input-field" placeholder="John Doe" />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-charcoal">Email</label>
          <input type="email" required value={form.email} onChange={(e) => update("email", e.target.value)} className="input-field" placeholder="you@example.com" />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-charcoal">Phone (optional)</label>
          <input value={form.phone} onChange={(e) => update("phone", e.target.value)} className="input-field" placeholder="+92 300 0000000" />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-charcoal">Password</label>
          <input type="password" required minLength={8} value={form.password} onChange={(e) => update("password", e.target.value)} className="input-field" placeholder="At least 8 characters" />
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-charcoal">Confirm Password</label>
          <input type="password" required value={form.confirm} onChange={(e) => update("confirm", e.target.value)} className="input-field" placeholder="Re-enter password" />
        </div>
        <button type="submit" disabled={loading} className="btn-primary w-full">
          {loading && <Loader2 size={16} className="animate-spin" />}
          Create Account
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-neutral-500">
        Already have an account?{" "}
        <Link href="/login" className="text-gold hover:underline">Login</Link>
      </p>
    </div>
  );
}
