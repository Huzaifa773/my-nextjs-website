import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { Hero } from "@/components/Hero";
import { ProductCard, ProductCardData } from "@/components/ProductCard";
import { StarRating } from "@/components/StarRating";

async function getWishlistedIds(userId?: string) {
  if (!userId) return new Set<string>();
  const wishlist = await prisma.wishlist.findUnique({
    where: { userId },
    include: { items: { select: { productId: true } } },
  });
  return new Set(wishlist?.items.map((i) => i.productId) || []);
}

function toCardData(p: any, wishlisted: Set<string>): ProductCardData {
  const ratings = p.reviews as { rating: number }[];
  const avgRating = ratings.length ? ratings.reduce((s, r) => s + r.rating, 0) / ratings.length : 0;
  return {
    id: p.id,
    name: p.name,
    brand: p.brand,
    price: Number(p.price),
    discountPrice: p.discountPrice ? Number(p.discountPrice) : null,
    stock: p.stock,
    images: p.images,
    avgRating,
    reviewCount: ratings.length,
    isWishlisted: wishlisted.has(p.id),
  };
}

const CATEGORY_ICONS: Record<string, string> = {
  "mens-perfumes": "https://images.unsplash.com/photo-1594035910387-fea47794261f?w=400&q=80",
  "womens-perfumes": "https://images.unsplash.com/photo-1587017539504-67cfbddac569?w=400&q=80",
  "oud": "https://images.unsplash.com/photo-1615368144592-0e5f56ec1a68?w=400&q=80",
  "attar": "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=400&q=80",
};

export default async function HomePage() {
  const session = await getServerSession(authOptions);
  const wishlisted = await getWishlistedIds(session?.user?.id);

  const productSelect = {
    id: true,
    name: true,
    brand: true,
    price: true,
    discountPrice: true,
    stock: true,
    images: { orderBy: { position: "asc" as const }, take: 1 },
    reviews: { select: { rating: true } },
  };

  const [featured, bestSellers, newArrivals, categories] = await Promise.all([
    prisma.product.findMany({ where: { isActive: true, isFeatured: true }, select: productSelect, take: 8 }),
    prisma.product.findMany({ where: { isActive: true, isBestSeller: true }, select: productSelect, take: 4 }),
    prisma.product.findMany({ where: { isActive: true, isNewArrival: true }, select: productSelect, take: 4 }),
    prisma.category.findMany({ where: { isActive: true }, take: 4 }),
  ]);

  const topReviews = await prisma.review.findMany({
    take: 3,
    orderBy: { rating: "desc" },
    include: { user: { select: { name: true } }, product: { select: { name: true } } },
  });

  return (
    <div>
      <Hero />

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 py-16 md:px-8">
        <h2 className="section-title mb-8 text-center">Shop by Category</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {categories.map((c) => (
            <Link key={c.id} href={`/products?category=${c.slug}`} className="group relative aspect-[4/5] overflow-hidden rounded-sm">
              <img
                src={CATEGORY_ICONS[c.slug] || "https://images.unsplash.com/photo-1541643600914-78b084683601?w=400&q=80"}
                alt={c.name}
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 flex items-end bg-gradient-to-t from-charcoal/80 to-transparent p-4">
                <span className="font-serif text-lg text-ivory">{c.name}</span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured */}
      {featured.length > 0 && (
        <section className="bg-white py-16">
          <div className="mx-auto max-w-7xl px-4 md:px-8">
            <div className="mb-8 flex items-center justify-between">
              <h2 className="section-title">Featured Perfumes</h2>
              <Link href="/products" className="text-sm text-gold hover:underline">View All →</Link>
            </div>
            <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
              {featured.map((p) => (
                <ProductCard key={p.id} product={toCardData(p, wishlisted)} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Best Sellers */}
      {bestSellers.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-16 md:px-8">
          <h2 className="section-title mb-8">Best Sellers</h2>
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            {bestSellers.map((p) => (
              <ProductCard key={p.id} product={toCardData(p, wishlisted)} />
            ))}
          </div>
        </section>
      )}

      {/* Promotional Banner */}
      <section className="bg-gold py-14 text-center text-charcoal">
        <h3 className="font-serif text-2xl md:text-3xl">Up to 20% Off Premium Oud Collection</h3>
        <p className="mt-2 text-sm">Limited time offer — while stocks last.</p>
        <Link href="/products?category=oud" className="btn-outline mt-6 inline-flex border-charcoal">
          Shop Oud Collection
        </Link>
      </section>

      {/* New Arrivals */}
      {newArrivals.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-16 md:px-8">
          <h2 className="section-title mb-8">New Arrivals</h2>
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            {newArrivals.map((p) => (
              <ProductCard key={p.id} product={toCardData(p, wishlisted)} />
            ))}
          </div>
        </section>
      )}

      {/* Reviews */}
      {topReviews.length > 0 && (
        <section className="bg-charcoal py-16 text-ivory">
          <div className="mx-auto max-w-7xl px-4 md:px-8">
            <h2 className="section-title mb-8 text-center text-ivory">What Our Customers Say</h2>
            <div className="grid gap-6 md:grid-cols-3">
              {topReviews.map((r) => (
                <div key={r.id} className="rounded-sm bg-charcoal-light p-6">
                  <StarRating rating={r.rating} />
                  <p className="mt-3 text-sm text-neutral-300">"{r.comment}"</p>
                  <p className="mt-4 text-xs uppercase tracking-wide text-gold">
                    {r.user.name} — {r.product.name}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
