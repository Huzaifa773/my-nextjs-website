import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getFilteredProducts } from "@/lib/products";
import { ProductCard, ProductCardData } from "@/components/ProductCard";
import { ProductFilters } from "@/components/ProductFilters";

async function getWishlistedIds(userId?: string) {
  if (!userId) return new Set<string>();
  const wishlist = await prisma.wishlist.findUnique({
    where: { userId },
    include: { items: { select: { productId: true } } },
  });
  return new Set(wishlist?.items.map((i) => i.productId) || []);
}

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | undefined };
}) {
  const session = await getServerSession(authOptions);
  const wishlisted = await getWishlistedIds(session?.user?.id);

  const { products, pagination } = await getFilteredProducts({
    search: searchParams.search,
    category: searchParams.category,
    minPrice: searchParams.minPrice ? parseFloat(searchParams.minPrice) : undefined,
    maxPrice: searchParams.maxPrice ? parseFloat(searchParams.maxPrice) : undefined,
    sort: (searchParams.sort as any) || "newest",
    page: searchParams.page ? parseInt(searchParams.page, 10) : 1,
  });

  const cardData: ProductCardData[] = products.map((p) => {
    const ratings = p.reviews;
    const avgRating = ratings.length ? ratings.reduce((s, r) => s + r.rating, 0) / ratings.length : 0;
    return {
      id: p.id,
      name: p.name,
      brand: p.brand,
      price: Number(p.price),
      discountPrice: p.discountPrice ? Number(p.discountPrice) : null,
      stock: p.stock,
      images: p.images,
      avgRating,
      reviewCount: ratings.length,
      isWishlisted: wishlisted.has(p.id),
    };
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 md:px-8">
      <h1 className="section-title mb-2">
        {searchParams.search ? `Results for "${searchParams.search}"` : "All Perfumes"}
      </h1>
      <p className="mb-8 text-sm text-neutral-500">{pagination.total} products found</p>

      <ProductFilters />

      {cardData.length === 0 ? (
        <div className="rounded-sm border border-dashed border-neutral-300 py-24 text-center text-neutral-500">
          No products match your filters. Try adjusting your search.
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-6 md:grid-cols-3 lg:grid-cols-4">
          {cardData.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}

      {pagination.totalPages > 1 && (
        <div className="mt-10 flex justify-center gap-2">
          {Array.from({ length: pagination.totalPages }, (_, i) => i + 1).map((p) => {
            const params = new URLSearchParams(searchParams as Record<string, string>);
            params.set("page", String(p));
            return (
              <Link
                key={p}
                href={`/products?${params.toString()}`}
                className={`flex h-9 w-9 items-center justify-center rounded-sm border text-sm ${
                  p === pagination.page ? "border-gold bg-gold text-charcoal" : "border-neutral-300 text-neutral-600"
                }`}
              >
                {p}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
