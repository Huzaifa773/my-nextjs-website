import { notFound } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatCurrency } from "@/lib/utils";
import { ProductGallery } from "@/components/ProductGallery";
import { ProductPurchasePanel } from "@/components/ProductPurchasePanel";
import { ReviewForm } from "@/components/ReviewForm";
import { StarRating } from "@/components/StarRating";
import { ProductCard, ProductCardData } from "@/components/ProductCard";

const FRAGRANCE_LABELS: Record<string, string> = {
  EAU_DE_PARFUM: "Eau de Parfum",
  EAU_DE_TOILETTE: "Eau de Toilette",
  EAU_DE_COLOGNE: "Eau de Cologne",
  PARFUM_EXTRAIT: "Parfum Extrait",
  ATTAR: "Attar",
  BODY_MIST: "Body Mist",
};

export default async function ProductDetailPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);

  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: {
      images: { orderBy: { position: "asc" } },
      category: true,
      reviews: { include: { user: { select: { name: true } } }, orderBy: { createdAt: "desc" } },
    },
  });

  if (!product || !product.isActive) notFound();

  let isWishlisted = false;
  if (session?.user) {
    const wishlist = await prisma.wishlist.findUnique({
      where: { userId: session.user.id },
      include: { items: { where: { productId: product.id } } },
    });
    isWishlisted = (wishlist?.items.length || 0) > 0;
  }

  const avgRating = product.reviews.length
    ? product.reviews.reduce((s, r) => s + r.rating, 0) / product.reviews.length
    : 0;

  const related = await prisma.product.findMany({
    where: { categoryId: product.categoryId, isActive: true, id: { not: product.id } },
    take: 4,
    include: { images: { orderBy: { position: "asc" }, take: 1 }, reviews: { select: { rating: true } } },
  });

  const relatedCards: ProductCardData[] = related.map((p) => {
    const ratings = p.reviews;
    return {
      id: p.id,
      name: p.name,
      brand: p.brand,
      price: Number(p.price),
      discountPrice: p.discountPrice ? Number(p.discountPrice) : null,
      stock: p.stock,
      images: p.images,
      avgRating: ratings.length ? ratings.reduce((s, r) => s + r.rating, 0) / ratings.length : 0,
      reviewCount: ratings.length,
    };
  });

  const hasDiscount = product.discountPrice != null && Number(product.discountPrice) < Number(product.price);

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 md:px-8">
      <div className="grid gap-10 md:grid-cols-2">
        <ProductGallery images={product.images} name={product.name} />

        <div>
          <p className="text-xs uppercase tracking-wide text-neutral-500">{product.brand}</p>
          <h1 className="mt-1 font-serif text-3xl text-charcoal">{product.name}</h1>

          {product.reviews.length > 0 && (
            <div className="mt-2">
              <StarRating rating={avgRating} count={product.reviews.length} />
            </div>
          )}

          <div className="mt-4 flex items-center gap-3">
            <span className="text-2xl font-semibold text-charcoal">
              {formatCurrency(hasDiscount ? product.discountPrice! : product.price)}
            </span>
            {hasDiscount && (
              <span className="text-lg text-neutral-400 line-through">{formatCurrency(product.price)}</span>
            )}
          </div>

          <p className="mt-4 text-sm leading-relaxed text-neutral-600">{product.description}</p>

          <dl className="mt-6 grid grid-cols-2 gap-y-2 text-sm">
            <dt className="text-neutral-500">Category</dt>
            <dd className="text-charcoal">{product.category.name}</dd>
            <dt className="text-neutral-500">Fragrance Type</dt>
            <dd className="text-charcoal">{FRAGRANCE_LABELS[product.fragranceType]}</dd>
            <dt className="text-neutral-500">Size</dt>
            <dd className="text-charcoal">{product.size}</dd>
            <dt className="text-neutral-500">Stock</dt>
            <dd className={product.stock > 0 ? "text-green-700" : "text-red-600"}>
              {product.stock > 0 ? `${product.stock} in stock` : "Out of stock"}
            </dd>
          </dl>

          <div className="mt-6">
            <ProductPurchasePanel productId={product.id} stock={product.stock} isWishlisted={isWishlisted} />
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-16 border-t border-neutral-200 pt-10">
        <h2 className="section-title mb-6">Customer Reviews</h2>
        <div className="grid gap-8 md:grid-cols-2">
          <div className="space-y-4">
            {product.reviews.length === 0 && (
              <p className="text-sm text-neutral-500">No reviews yet. Be the first to review this product.</p>
            )}
            {product.reviews.map((r) => (
              <div key={r.id} className="border-b border-neutral-100 pb-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-charcoal">{r.user.name}</span>
                  <StarRating rating={r.rating} />
                </div>
                {r.comment && <p className="mt-1 text-sm text-neutral-600">{r.comment}</p>}
              </div>
            ))}
          </div>
          <ReviewForm productId={product.id} />
        </div>
      </section>

      {/* Related Products */}
      {relatedCards.length > 0 && (
        <section className="mt-16 border-t border-neutral-200 pt-10">
          <h2 className="section-title mb-6">You May Also Like</h2>
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            {relatedCards.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
