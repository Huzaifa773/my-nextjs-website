import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { CheckoutForm } from "@/components/CheckoutForm";

const FREE_SHIPPING_THRESHOLD = 15000;
const FLAT_SHIPPING_COST = 500;

export default async function CheckoutPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login?callbackUrl=/checkout");

  const cart = await prisma.cart.findUnique({ where: { userId: session.user.id } });
  const cartItems = cart
    ? await prisma.cartItem.findMany({
        where: { cartId: cart.id },
        include: { product: true },
      })
    : [];

  if (cartItems.length === 0) {
    redirect("/cart");
  }

  const addresses = await prisma.address.findMany({
    where: { userId: session.user.id },
    orderBy: [{ isDefault: "desc" }, { createdAt: "desc" }],
  });

  const subtotal = cartItems.reduce((sum, item) => {
    const price = item.product.discountPrice ? Number(item.product.discountPrice) : Number(item.product.price);
    return sum + price * item.quantity;
  }, 0);
  const shipping = subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : FLAT_SHIPPING_COST;
  const total = subtotal + shipping;

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 md:px-8">
      <h1 className="section-title mb-8">Checkout</h1>
      <CheckoutForm
        addresses={addresses.map((a) => ({
          id: a.id,
          fullName: a.fullName,
          phone: a.phone,
          line1: a.line1,
          line2: a.line2,
          city: a.city,
          province: a.province,
          postalCode: a.postalCode,
          country: a.country,
          isDefault: a.isDefault,
        }))}
        subtotal={subtotal}
        shipping={shipping}
        total={total}
      />
    </div>
  );
}
