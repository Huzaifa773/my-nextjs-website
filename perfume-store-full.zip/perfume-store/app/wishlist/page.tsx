import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ProductCard, ProductCardData } from "@/components/ProductCard";

export default async function WishlistPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login?callbackUrl=/wishlist");

  const wishlist = await prisma.wishlist.findUnique({ where: { userId: session.user.id } });
  const items = wishlist
    ? await prisma.wishlistItem.findMany({
        where: { wishlistId: wishlist.id },
        include: {
          product: {
            include: { images: { orderBy: { position: "asc" }, take: 1 }, reviews: { select: { rating: true } } },
          },
        },
        orderBy: { createdAt: "desc" },
      })
    : [];

  const cards: ProductCardData[] = items.map(({ product: p }) => {
    const ratings = p.reviews;
    return {
      id: p.id,
      name: p.name,
      brand: p.brand,
      price: Number(p.price),
      discountPrice: p.discountPrice ? Number(p.discountPrice) : null,
      stock: p.stock,
      images: p.images,
      avgRating: ratings.length ? ratings.reduce((s, r) => s + r.rating, 0) / ratings.length : 0,
      reviewCount: ratings.length,
      isWishlisted: true,
    };
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 md:px-8">
      <h1 className="section-title mb-8">My Wishlist</h1>
      {cards.length === 0 ? (
        <div className="rounded-sm border border-dashed border-neutral-300 py-24 text-center text-neutral-500">
          Your wishlist is empty.
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
          {cards.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
