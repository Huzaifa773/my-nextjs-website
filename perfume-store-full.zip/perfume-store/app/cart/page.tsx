import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { CartClient } from "@/components/CartClient";

export default async function CartPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login?callbackUrl=/cart");

  const cart = await prisma.cart.findUnique({ where: { userId: session.user.id } });
  const items = cart
    ? await prisma.cartItem.findMany({
        where: { cartId: cart.id },
        include: { product: { include: { images: { orderBy: { position: "asc" }, take: 1 } } } },
        orderBy: { createdAt: "desc" },
      })
    : [];

  const formatted = items.map((i) => ({
    id: i.id,
    quantity: i.quantity,
    product: {
      id: i.product.id,
      name: i.product.name,
      brand: i.product.brand,
      price: Number(i.product.price),
      discountPrice: i.product.discountPrice ? Number(i.product.discountPrice) : null,
      stock: i.product.stock,
      images: i.product.images,
    },
  }));

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 md:px-8">
      <h1 className="section-title mb-8">Shopping Cart</h1>
      <CartClient initialItems={formatted} />
    </div>
  );
}
