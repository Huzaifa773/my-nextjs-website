import { notFound, redirect } from "next/navigation";
import Link from "next/link";
import { getServerSession } from "next-auth";
import { CheckCircle2 } from "lucide-react";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatCurrency } from "@/lib/utils";
import { BankTransferProofForm } from "@/components/BankTransferProofForm";

const STATUS_LABELS: Record<string, string> = {
  PENDING: "Pending",
  PAID: "Paid",
  FAILED: "Failed",
  REFUNDED: "Refunded",
};

export default async function OrderConfirmationPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login");

  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: { items: true, address: true, payments: { orderBy: { createdAt: "desc" } } },
  });

  if (!order || order.userId !== session.user.id) notFound();

  const latestPayment = order.payments[0];

  return (
    <div className="mx-auto max-w-3xl px-4 py-16 md:px-8">
      <div className="text-center">
        <CheckCircle2 className="mx-auto mb-4 text-green-600" size={56} />
        <h1 className="section-title">Order Placed Successfully</h1>
        <p className="mt-2 text-neutral-500">Order Number: <span className="font-medium text-charcoal">{order.orderNumber}</span></p>
      </div>

      <div className="mt-10 rounded-sm border border-neutral-200 p-6">
        <div className="flex flex-wrap justify-between gap-4 border-b border-neutral-200 pb-4 text-sm">
          <div>
            <p className="text-neutral-500">Payment Method</p>
            <p className="font-medium text-charcoal">{order.paymentMethod.replace("_", " ")}</p>
          </div>
          <div>
            <p className="text-neutral-500">Payment Status</p>
            <p className="font-medium text-charcoal">{STATUS_LABELS[order.paymentStatus]}</p>
          </div>
          <div>
            <p className="text-neutral-500">Order Status</p>
            <p className="font-medium text-charcoal">{order.orderStatus}</p>
          </div>
          <div>
            <p className="text-neutral-500">Total</p>
            <p className="font-medium text-charcoal">{formatCurrency(order.total)}</p>
          </div>
        </div>

        <div className="mt-4 space-y-2">
          {order.items.map((item) => (
            <div key={item.id} className="flex justify-between text-sm">
              <span>{item.name} × {item.quantity}</span>
              <span>{formatCurrency(Number(item.price) * item.quantity)}</span>
            </div>
          ))}
        </div>

        <div className="mt-4 border-t border-neutral-200 pt-4 text-sm text-neutral-600">
          <p className="font-medium text-charcoal">Shipping to:</p>
          <p>{order.address.fullName}, {order.address.line1}, {order.address.city}, {order.address.province} {order.address.postalCode}</p>
        </div>
      </div>

      {/* Bank Transfer instructions + proof submission */}
      {order.paymentMethod === "BANK_TRANSFER" && (
        <div className="mt-8 rounded-sm border border-gold bg-champagne/30 p-6">
          <h2 className="mb-2 font-serif text-lg text-charcoal">Complete Your Bank Transfer</h2>
          <div className="mb-4 space-y-1 text-sm text-neutral-700">
            <p>Account Title: <strong>{process.env.BANK_TRANSFER_ACCOUNT_TITLE || "—"}</strong></p>
            <p>Bank: <strong>{process.env.BANK_TRANSFER_BANK_NAME || "—"}</strong></p>
            <p>Account Number: <strong>{process.env.BANK_TRANSFER_ACCOUNT_NUMBER || "—"}</strong></p>
            <p>IBAN: <strong>{process.env.BANK_TRANSFER_IBAN || "—"}</strong></p>
            <p>Amount: <strong>{formatCurrency(order.total)}</strong></p>
          </div>
          {latestPayment?.status === "AWAITING_VERIFICATION" ? (
            <p className="text-sm text-green-700">
              Your reference has been submitted and is awaiting admin verification.
            </p>
          ) : (
            <BankTransferProofForm orderId={order.id} />
          )}
        </div>
      )}

      {/* Gateway payment status */}
      {["JAZZCASH", "EASYPAISA", "SAFEPAY"].includes(order.paymentMethod) && (
        <div className="mt-8 rounded-sm border border-neutral-200 p-6 text-sm">
          {order.paymentStatus === "PAID" ? (
            <p className="text-green-700">Payment confirmed via {order.paymentMethod}.</p>
          ) : order.paymentStatus === "FAILED" ? (
            <p className="text-red-600">
              Payment was not completed. You can{" "}
              <Link href={`/api/payments/${order.paymentMethod.toLowerCase()}/initiate?orderId=${order.id}`} className="text-gold underline">
                try again
              </Link>.
            </p>
          ) : (
            <p className="text-neutral-500">Waiting for payment confirmation from {order.paymentMethod}...</p>
          )}
        </div>
      )}

      <div className="mt-10 text-center">
        <Link href="/dashboard/orders" className="btn-outline mr-3">View My Orders</Link>
        <Link href="/products" className="btn-primary">Continue Shopping</Link>
      </div>
    </div>
  );
}
