import Link from "next/link";
import Image from "next/image";

export function Hero() {
  return (
    <section className="relative flex min-h-[70vh] items-center overflow-hidden bg-charcoal text-ivory">
      <Image
        src="https://images.unsplash.com/photo-1541643600914-78b084683601?w=1600&q=80"
        alt="Luxury perfume bottle"
        fill
        priority
        className="object-cover opacity-40"
      />
      <div className="relative z-10 mx-auto max-w-7xl px-4 py-24 md:px-8">
        <p className="mb-4 text-sm uppercase tracking-[0.3em] text-gold">The Art of Fragrance</p>
        <h1 className="max-w-2xl font-serif text-4xl leading-tight md:text-6xl">
          Discover Scents That Define <span className="text-gold">You</span>
        </h1>
        <p className="mt-6 max-w-lg text-neutral-300">
          Handcrafted perfumes, oud, and attar — designed for those who
          appreciate timeless luxury and unforgettable presence.
        </p>
        <div className="mt-8 flex gap-4">
          <Link href="/products" className="btn-primary bg-gold text-charcoal hover:bg-ivory">
            Shop Collection
          </Link>
          <Link href="/products?category=premium-collection" className="btn-outline border-ivory text-ivory hover:bg-ivory hover:text-charcoal">
            Premium Collection
          </Link>
        </div>
      </div>
    </section>
  );
}
