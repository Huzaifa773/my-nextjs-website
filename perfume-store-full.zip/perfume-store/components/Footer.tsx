import Link from "next/link";
import { Instagram, Facebook, Twitter, Mail } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-charcoal text-neutral-300">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-4 md:px-8">
        <div>
          <h3 className="font-serif text-xl text-gold">MAISON CHARCOAL</h3>
          <p className="mt-3 text-sm leading-relaxed text-neutral-400">
            A luxury fragrance house crafting timeless perfumes, oud and attar
            for men, women, and every occasion.
          </p>
          <div className="mt-4 flex gap-4">
            <Instagram size={18} className="hover:text-gold cursor-pointer" />
            <Facebook size={18} className="hover:text-gold cursor-pointer" />
            <Twitter size={18} className="hover:text-gold cursor-pointer" />
          </div>
        </div>

        <div>
          <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-gold">Shop</h4>
          <ul className="space-y-2 text-sm">
            <li><Link href="/products" className="hover:text-gold">All Products</Link></li>
            <li><Link href="/products?category=mens-perfumes" className="hover:text-gold">Men's Perfumes</Link></li>
            <li><Link href="/products?category=womens-perfumes" className="hover:text-gold">Women's Perfumes</Link></li>
            <li><Link href="/products?category=gift-sets" className="hover:text-gold">Gift Sets</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-gold">Account</h4>
          <ul className="space-y-2 text-sm">
            <li><Link href="/dashboard" className="hover:text-gold">My Dashboard</Link></li>
            <li><Link href="/dashboard/orders" className="hover:text-gold">Order History</Link></li>
            <li><Link href="/wishlist" className="hover:text-gold">Wishlist</Link></li>
            <li><Link href="/cart" className="hover:text-gold">Cart</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-4 text-sm font-semibold uppercase tracking-wider text-gold">Newsletter</h4>
          <p className="mb-3 text-sm text-neutral-400">Get updates on new arrivals and offers.</p>
          <form className="flex" onSubmit={(e) => e.preventDefault()}>
            <input
              type="email"
              placeholder="Your email"
              className="w-full rounded-l-sm border border-charcoal-medium bg-charcoal-light px-3 py-2 text-sm text-ivory placeholder:text-neutral-500 focus:outline-none"
            />
            <button className="rounded-r-sm bg-gold px-3 text-charcoal">
              <Mail size={16} />
            </button>
          </form>
        </div>
      </div>

      <div className="border-t border-charcoal-medium py-6 text-center text-xs text-neutral-500">
        © {new Date().getFullYear()} Maison Charcoal. All rights reserved.
      </div>
    </footer>
  );
}
