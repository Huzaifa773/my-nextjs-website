"use client";

import { useState } from "react";
import Image from "next/image";

export function ProductGallery({ images, name }: { images: { url: string; altText: string | null }[]; name: string }) {
  const list = images.length ? images : [{ url: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=800&q=80", altText: name }];
  const [active, setActive] = useState(0);

  return (
    <div>
      <div className="relative aspect-square overflow-hidden rounded-sm bg-neutral-100">
        <Image src={list[active].url} alt={list[active].altText || name} fill className="object-cover" priority />
      </div>
      {list.length > 1 && (
        <div className="mt-3 flex gap-2">
          {list.map((img, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`relative h-16 w-16 overflow-hidden rounded-sm border-2 ${
                i === active ? "border-gold" : "border-transparent"
              }`}
            >
              <Image src={img.url} alt={img.altText || name} fill className="object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
