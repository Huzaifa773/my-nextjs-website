"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { Heart } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export function WishlistButton({
  productId,
  initialWishlisted = false,
  className,
}: {
  productId: string;
  initialWishlisted?: boolean;
  className?: string;
}) {
  const { status } = useSession();
  const router = useRouter();
  const [wishlisted, setWishlisted] = useState(initialWishlisted);
  const [loading, setLoading] = useState(false);

  async function toggle(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();

    if (status !== "authenticated") {
      toast.info("Please log in to use your wishlist");
      router.push("/login");
      return;
    }

    setLoading(true);
    try {
      if (wishlisted) {
        const res = await fetch(`/api/wishlist/${productId}`, { method: "DELETE" });
        if (!res.ok) throw new Error();
        setWishlisted(false);
        toast.success("Removed from wishlist");
      } else {
        const res = await fetch("/api/wishlist", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ productId }),
        });
        if (!res.ok) throw new Error();
        setWishlisted(true);
        toast.success("Added to wishlist");
      }
    } catch {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      onClick={toggle}
      disabled={loading}
      aria-label="Toggle wishlist"
      className={cn(
        "flex h-9 w-9 items-center justify-center rounded-full bg-white/90 shadow transition-colors hover:bg-white disabled:opacity-50",
        className
      )}
    >
      <Heart size={18} className={wishlisted ? "fill-gold text-gold" : "text-charcoal"} />
    </button>
  );
}
