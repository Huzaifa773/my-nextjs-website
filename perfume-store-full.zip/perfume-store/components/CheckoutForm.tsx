"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, Truck, Landmark, Smartphone, CreditCard } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

export interface AddressData {
  id: string;
  fullName: string;
  phone: string;
  line1: string;
  line2: string | null;
  city: string;
  province: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
}

const PAYMENT_METHODS = [
  { value: "COD", label: "Cash on Delivery", icon: Truck, hint: "Pay when your order arrives" },
  { value: "BANK_TRANSFER", label: "Bank Transfer", icon: Landmark, hint: "Manual transfer, verified by our team" },
  { value: "JAZZCASH", label: "JazzCash", icon: Smartphone, hint: "Pay via JazzCash mobile wallet" },
  { value: "EASYPAISA", label: "Easypaisa", icon: Smartphone, hint: "Pay via Easypaisa mobile wallet" },
  { value: "SAFEPAY", label: "Card / Safepay", icon: CreditCard, hint: "Pay by debit/credit card" },
] as const;

export function CheckoutForm({
  addresses,
  subtotal,
  shipping,
  total,
}: {
  addresses: AddressData[];
  subtotal: number;
  shipping: number;
  total: number;
}) {
  const router = useRouter();
  const [selectedAddressId, setSelectedAddressId] = useState(addresses.find((a) => a.isDefault)?.id || addresses[0]?.id || "");
  const [showNewAddress, setShowNewAddress] = useState(addresses.length === 0);
  const [paymentMethod, setPaymentMethod] = useState<(typeof PAYMENT_METHODS)[number]["value"]>("COD");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  const [newAddress, setNewAddress] = useState({
    fullName: "", phone: "", line1: "", line2: "", city: "", province: "", postalCode: "", country: "Pakistan",
  });

  function updateNewAddress(field: string, value: string) {
    setNewAddress((a) => ({ ...a, [field]: value }));
  }

  async function handlePlaceOrder(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      let addressId = selectedAddressId;

      if (showNewAddress) {
        const res = await fetch("/api/addresses", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...newAddress, isDefault: addresses.length === 0 }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Failed to save address");
        addressId = data.address.id;
      }

      if (!addressId) throw new Error("Please select or add a shipping address");

      const orderRes = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ addressId, paymentMethod, notes: notes || undefined }),
      });
      const orderData = await orderRes.json();
      if (!orderRes.ok) throw new Error(orderData.error || "Failed to place order");

      const orderId = orderData.order.id;

      // For online gateways, hand off to the initiate route which builds the
      // signed redirect to the actual payment provider.
      if (paymentMethod === "JAZZCASH") {
        window.location.href = `/api/payments/jazzcash/initiate?orderId=${orderId}`;
        return;
      }
      if (paymentMethod === "EASYPAISA") {
        window.location.href = `/api/payments/easypaisa/initiate?orderId=${orderId}`;
        return;
      }
      if (paymentMethod === "SAFEPAY") {
        window.location.href = `/api/payments/safepay/initiate?orderId=${orderId}`;
        return;
      }

      // COD / Bank Transfer go straight to the confirmation page
      router.push(`/order-confirmation/${orderId}`);
    } catch (err: any) {
      toast.error(err.message || "Something went wrong");
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handlePlaceOrder} className="grid gap-10 lg:grid-cols-3">
      <div className="space-y-8 lg:col-span-2">
        {/* Shipping Address */}
        <div>
          <h2 className="mb-4 font-serif text-xl text-charcoal">Shipping Address</h2>
          {addresses.length > 0 && !showNewAddress && (
            <div className="space-y-3">
              {addresses.map((a) => (
                <label
                  key={a.id}
                  className={`flex cursor-pointer gap-3 rounded-sm border p-4 text-sm ${
                    selectedAddressId === a.id ? "border-gold bg-champagne/30" : "border-neutral-200"
                  }`}
                >
                  <input
                    type="radio"
                    name="address"
                    checked={selectedAddressId === a.id}
                    onChange={() => setSelectedAddressId(a.id)}
                    className="mt-1"
                  />
                  <div>
                    <p className="font-medium text-charcoal">{a.fullName} · {a.phone}</p>
                    <p className="text-neutral-600">{a.line1}{a.line2 ? `, ${a.line2}` : ""}, {a.city}, {a.province} {a.postalCode}</p>
                  </div>
                </label>
              ))}
              <button type="button" onClick={() => setShowNewAddress(true)} className="text-sm text-gold hover:underline">
                + Use a different address
              </button>
            </div>
          )}

          {showNewAddress && (
            <div className="grid gap-3 sm:grid-cols-2">
              <input required placeholder="Full Name" value={newAddress.fullName} onChange={(e) => updateNewAddress("fullName", e.target.value)} className="input-field" />
              <input required placeholder="Phone" value={newAddress.phone} onChange={(e) => updateNewAddress("phone", e.target.value)} className="input-field" />
              <input required placeholder="Address Line 1" value={newAddress.line1} onChange={(e) => updateNewAddress("line1", e.target.value)} className="input-field sm:col-span-2" />
              <input placeholder="Address Line 2 (optional)" value={newAddress.line2} onChange={(e) => updateNewAddress("line2", e.target.value)} className="input-field sm:col-span-2" />
              <input required placeholder="City" value={newAddress.city} onChange={(e) => updateNewAddress("city", e.target.value)} className="input-field" />
              <input required placeholder="Province" value={newAddress.province} onChange={(e) => updateNewAddress("province", e.target.value)} className="input-field" />
              <input required placeholder="Postal Code" value={newAddress.postalCode} onChange={(e) => updateNewAddress("postalCode", e.target.value)} className="input-field" />
              <input required placeholder="Country" value={newAddress.country} onChange={(e) => updateNewAddress("country", e.target.value)} className="input-field" />
              {addresses.length > 0 && (
                <button type="button" onClick={() => setShowNewAddress(false)} className="text-left text-sm text-gold hover:underline sm:col-span-2">
                  ← Use a saved address instead
                </button>
              )}
            </div>
          )}
        </div>

        {/* Payment Method */}
        <div>
          <h2 className="mb-4 font-serif text-xl text-charcoal">Payment Method</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {PAYMENT_METHODS.map((m) => {
              const Icon = m.icon;
              return (
                <label
                  key={m.value}
                  className={`flex cursor-pointer items-start gap-3 rounded-sm border p-4 text-sm ${
                    paymentMethod === m.value ? "border-gold bg-champagne/30" : "border-neutral-200"
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={paymentMethod === m.value}
                    onChange={() => setPaymentMethod(m.value)}
                    className="mt-1"
                  />
                  <Icon size={18} className="mt-0.5 text-gold" />
                  <div>
                    <p className="font-medium text-charcoal">{m.label}</p>
                    <p className="text-xs text-neutral-500">{m.hint}</p>
                  </div>
                </label>
              );
            })}
          </div>
        </div>

        <div>
          <label className="mb-1 block text-sm font-medium text-charcoal">Order Notes (optional)</label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className="input-field" placeholder="Any special instructions..." />
        </div>
      </div>

      {/* Order Summary */}
      <div className="h-fit rounded-sm border border-neutral-200 p-6">
        <h3 className="mb-4 font-serif text-xl text-charcoal">Order Summary</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-neutral-500">Subtotal</span><span>{formatCurrency(subtotal)}</span></div>
          <div className="flex justify-between"><span className="text-neutral-500">Shipping</span><span>{shipping === 0 ? "Free" : formatCurrency(shipping)}</span></div>
          <div className="flex justify-between border-t border-neutral-200 pt-2 font-semibold text-charcoal"><span>Total</span><span>{formatCurrency(total)}</span></div>
        </div>
        <button type="submit" disabled={loading} className="btn-primary mt-6 w-full">
          {loading && <Loader2 size={16} className="animate-spin" />}
          Place Order
        </button>
      </div>
    </form>
  );
}
