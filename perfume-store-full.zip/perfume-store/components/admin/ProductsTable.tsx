"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Pencil, Trash2, Loader2 } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

export interface AdminProductRow {
  id: string;
  name: string;
  sku: string;
  price: number;
  stock: number;
  isActive: boolean;
  createdAt: string;
  category: { name: string };
  images: { url: string }[];
}

export function ProductsTable({ products }: { products: AdminProductRow[] }) {
  const router = useRouter();
  const [busyId, setBusyId] = useState<string | null>(null);
  const [rows, setRows] = useState(products);

  async function handleDelete(id: string) {
    if (!confirm("Are you sure you want to delete this product?")) return;
    setBusyId(id);
    try {
      const res = await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to delete");
      if (data.softDeleted) {
        toast.info("Product has existing orders — deactivated instead of deleted");
        setRows((r) => r.map((p) => (p.id === id ? { ...p, isActive: false } : p)));
      } else {
        setRows((r) => r.filter((p) => p.id !== id));
        toast.success("Product deleted");
      }
      router.refresh();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="overflow-x-auto rounded-sm border border-neutral-200 bg-white">
      <table className="w-full min-w-[700px] text-sm">
        <thead className="border-b border-neutral-200 bg-neutral-50 text-left text-xs uppercase tracking-wide text-neutral-500">
          <tr>
            <th className="px-4 py-3">Image</th>
            <th className="px-4 py-3">Name</th>
            <th className="px-4 py-3">Category</th>
            <th className="px-4 py-3">Price</th>
            <th className="px-4 py-3">Stock</th>
            <th className="px-4 py-3">Status</th>
            <th className="px-4 py-3 text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((p) => (
            <tr key={p.id} className="border-b border-neutral-100">
              <td className="px-4 py-3">
                <img src={p.images[0]?.url || "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=100&q=80"} alt={p.name} className="h-10 w-10 rounded-sm object-cover" />
              </td>
              <td className="px-4 py-3">
                <p className="font-medium text-charcoal">{p.name}</p>
                <p className="text-xs text-neutral-500">{p.sku}</p>
              </td>
              <td className="px-4 py-3">{p.category.name}</td>
              <td className="px-4 py-3">{formatCurrency(p.price)}</td>
              <td className="px-4 py-3">{p.stock}</td>
              <td className="px-4 py-3">
                <span className={`rounded-full px-2 py-1 text-xs ${p.isActive ? "bg-green-100 text-green-700" : "bg-neutral-200 text-neutral-600"}`}>
                  {p.isActive ? "Active" : "Inactive"}
                </span>
              </td>
              <td className="px-4 py-3 text-right">
                <div className="flex justify-end gap-3">
                  <Link href={`/admin/products/${p.id}/edit`} className="text-neutral-500 hover:text-gold"><Pencil size={16} /></Link>
                  <button disabled={busyId === p.id} onClick={() => handleDelete(p.id)} className="text-neutral-500 hover:text-red-600">
                    {busyId === p.id ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
