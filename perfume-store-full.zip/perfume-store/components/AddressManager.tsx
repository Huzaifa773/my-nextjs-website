"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Plus, Trash2, Star, Loader2 } from "lucide-react";

export interface AddressItem {
  id: string;
  fullName: string;
  phone: string;
  line1: string;
  line2: string | null;
  city: string;
  province: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
}

const empty = { fullName: "", phone: "", line1: "", line2: "", city: "", province: "", postalCode: "", country: "Pakistan" };

export function AddressManager({ initialAddresses }: { initialAddresses: AddressItem[] }) {
  const router = useRouter();
  const [addresses, setAddresses] = useState(initialAddresses);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/addresses", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to add address");
      setAddresses((a) => [data.address, ...a]);
      setForm(empty);
      setShowForm(false);
      toast.success("Address added");
      router.refresh();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function setDefault(id: string) {
    setBusyId(id);
    try {
      const res = await fetch(`/api/addresses/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isDefault: true }),
      });
      if (!res.ok) throw new Error("Failed to update");
      setAddresses((prev) => prev.map((a) => ({ ...a, isDefault: a.id === id })));
      router.refresh();
    } catch {
      toast.error("Something went wrong");
    } finally {
      setBusyId(null);
    }
  }

  async function removeAddress(id: string) {
    setBusyId(id);
    try {
      const res = await fetch(`/api/addresses/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
      setAddresses((prev) => prev.filter((a) => a.id !== id));
      toast.success("Address removed");
      router.refresh();
    } catch {
      toast.error("Something went wrong");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-4">
      {addresses.map((a) => (
        <div key={a.id} className="flex items-start justify-between rounded-sm border border-neutral-200 p-4 text-sm">
          <div>
            <p className="flex items-center gap-2 font-medium text-charcoal">
              {a.fullName} {a.isDefault && <span className="rounded-full bg-gold px-2 py-0.5 text-[10px] text-charcoal">Default</span>}
            </p>
            <p className="text-neutral-600">{a.phone}</p>
            <p className="text-neutral-600">{a.line1}{a.line2 ? `, ${a.line2}` : ""}, {a.city}, {a.province} {a.postalCode}</p>
          </div>
          <div className="flex flex-col items-end gap-2">
            {!a.isDefault && (
              <button onClick={() => setDefault(a.id)} disabled={busyId === a.id} className="flex items-center gap-1 text-xs text-gold hover:underline">
                <Star size={12} /> Set Default
              </button>
            )}
            <button onClick={() => removeAddress(a.id)} disabled={busyId === a.id} className="text-neutral-400 hover:text-red-600">
              {busyId === a.id ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
            </button>
          </div>
        </div>
      ))}

      {showForm ? (
        <form onSubmit={handleAdd} className="grid gap-3 rounded-sm border border-neutral-200 p-4 sm:grid-cols-2">
          <input required placeholder="Full Name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} className="input-field" />
          <input required placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input-field" />
          <input required placeholder="Address Line 1" value={form.line1} onChange={(e) => setForm({ ...form, line1: e.target.value })} className="input-field sm:col-span-2" />
          <input placeholder="Address Line 2" value={form.line2} onChange={(e) => setForm({ ...form, line2: e.target.value })} className="input-field sm:col-span-2" />
          <input required placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="input-field" />
          <input required placeholder="Province" value={form.province} onChange={(e) => setForm({ ...form, province: e.target.value })} className="input-field" />
          <input required placeholder="Postal Code" value={form.postalCode} onChange={(e) => setForm({ ...form, postalCode: e.target.value })} className="input-field" />
          <input required placeholder="Country" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} className="input-field" />
          <div className="flex gap-3 sm:col-span-2">
            <button type="submit" disabled={loading} className="btn-primary text-sm">
              {loading && <Loader2 size={16} className="animate-spin" />} Save Address
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="btn-outline text-sm">Cancel</button>
          </div>
        </form>
      ) : (
        <button onClick={() => setShowForm(true)} className="flex items-center gap-2 text-sm text-gold hover:underline">
          <Plus size={16} /> Add New Address
        </button>
      )}
    </div>
  );
}
