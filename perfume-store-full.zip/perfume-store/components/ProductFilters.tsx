"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useState } from "react";
import { SlidersHorizontal } from "lucide-react";

const CATEGORIES = [
  { name: "All", slug: "" },
  { name: "Men's Perfumes", slug: "mens-perfumes" },
  { name: "Women's Perfumes", slug: "womens-perfumes" },
  { name: "Unisex Perfumes", slug: "unisex-perfumes" },
  { name: "Oud", slug: "oud" },
  { name: "Attar", slug: "attar" },
  { name: "Gift Sets", slug: "gift-sets" },
  { name: "Premium Collection", slug: "premium-collection" },
  { name: "New Arrivals", slug: "new-arrivals" },
];

export function ProductFilters() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [open, setOpen] = useState(false);

  function setParam(key: string, value: string) {
    const params = new URLSearchParams(searchParams.toString());
    if (value) params.set(key, value);
    else params.delete(key);
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  }

  return (
    <div className="mb-8 space-y-4">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setOpen((v) => !v)}
          className="flex items-center gap-2 text-sm font-medium text-charcoal md:hidden"
        >
          <SlidersHorizontal size={16} /> Filters
        </button>
        <select
          value={searchParams.get("sort") || "newest"}
          onChange={(e) => setParam("sort", e.target.value)}
          className="ml-auto rounded-sm border border-neutral-300 px-3 py-2 text-sm"
        >
          <option value="newest">Newest</option>
          <option value="price_asc">Price: Low to High</option>
          <option value="price_desc">Price: High to Low</option>
          <option value="popular">Popular</option>
        </select>
      </div>

      <div className={`${open ? "flex" : "hidden"} flex-wrap gap-2 md:flex`}>
        {CATEGORIES.map((c) => {
          const active = (searchParams.get("category") || "") === c.slug;
          return (
            <button
              key={c.slug || "all"}
              onClick={() => setParam("category", c.slug)}
              className={`rounded-full border px-4 py-1.5 text-xs tracking-wide transition-colors ${
                active ? "border-gold bg-gold text-charcoal" : "border-neutral-300 text-neutral-600 hover:border-gold"
              }`}
            >
              {c.name}
            </button>
          );
        })}
      </div>

      <div className={`${open ? "flex" : "hidden"} items-center gap-3 md:flex`}>
        <span className="text-xs text-neutral-500">Price:</span>
        <input
          type="number"
          placeholder="Min"
          defaultValue={searchParams.get("minPrice") || ""}
          onBlur={(e) => setParam("minPrice", e.target.value)}
          className="w-24 rounded-sm border border-neutral-300 px-2 py-1 text-sm"
        />
        <span className="text-neutral-400">–</span>
        <input
          type="number"
          placeholder="Max"
          defaultValue={searchParams.get("maxPrice") || ""}
          onBlur={(e) => setParam("maxPrice", e.target.value)}
          className="w-24 rounded-sm border border-neutral-300 px-2 py-1 text-sm"
        />
      </div>
    </div>
  );
}
