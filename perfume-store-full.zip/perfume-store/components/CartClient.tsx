"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Minus, Plus, Trash2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/utils";

export interface CartItemData {
  id: string;
  quantity: number;
  product: {
    id: string;
    name: string;
    brand: string;
    price: number;
    discountPrice: number | null;
    stock: number;
    images: { url: string; altText: string | null }[];
  };
}

export function CartClient({ initialItems }: { initialItems: CartItemData[] }) {
  const router = useRouter();
  const [items, setItems] = useState(initialItems);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function updateQuantity(itemId: string, quantity: number) {
    if (quantity < 1) return;
    setBusyId(itemId);
    try {
      const res = await fetch(`/api/cart/${itemId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ quantity }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to update");
      setItems((prev) => prev.map((i) => (i.id === itemId ? { ...i, quantity } : i)));
      router.refresh();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setBusyId(null);
    }
  }

  async function removeItem(itemId: string) {
    setBusyId(itemId);
    try {
      const res = await fetch(`/api/cart/${itemId}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to remove item");
      setItems((prev) => prev.filter((i) => i.id !== itemId));
      toast.success("Item removed");
      router.refresh();
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setBusyId(null);
    }
  }

  const subtotal = items.reduce((sum, i) => {
    const price = i.product.discountPrice ?? i.product.price;
    return sum + price * i.quantity;
  }, 0);
  const shipping = subtotal > 0 ? (subtotal >= 15000 ? 0 : 500) : 0;
  const total = subtotal + shipping;

  if (items.length === 0) {
    return (
      <div className="rounded-sm border border-dashed border-neutral-300 py-24 text-center">
        <p className="text-neutral-500">Your cart is empty.</p>
        <Link href="/products" className="btn-primary mt-6 inline-flex">Continue Shopping</Link>
      </div>
    );
  }

  return (
    <div className="grid gap-10 lg:grid-cols-3">
      <div className="space-y-4 lg:col-span-2">
        {items.map((item) => {
          const price = item.product.discountPrice ?? item.product.price;
          return (
            <div key={item.id} className="flex gap-4 rounded-sm border border-neutral-200 p-4">
              <div className="relative h-24 w-24 flex-shrink-0 overflow-hidden rounded-sm bg-neutral-100">
                <Image
                  src={item.product.images[0]?.url || "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=200&q=80"}
                  alt={item.product.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="flex flex-1 flex-col justify-between">
                <div>
                  <Link href={`/products/${item.product.id}`} className="font-serif text-lg text-charcoal hover:text-gold">
                    {item.product.name}
                  </Link>
                  <p className="text-xs text-neutral-500">{item.product.brand}</p>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center rounded-sm border border-neutral-300">
                    <button
                      disabled={busyId === item.id}
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="p-2 hover:text-gold disabled:opacity-50"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="w-8 text-center text-sm">{item.quantity}</span>
                    <button
                      disabled={busyId === item.id || item.quantity >= item.product.stock}
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="p-2 hover:text-gold disabled:opacity-50"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <span className="font-medium text-charcoal">{formatCurrency(price * item.quantity)}</span>
                </div>
              </div>
              <button
                disabled={busyId === item.id}
                onClick={() => removeItem(item.id)}
                className="self-start text-neutral-400 hover:text-red-600"
              >
                {busyId === item.id ? <Loader2 size={18} className="animate-spin" /> : <Trash2 size={18} />}
              </button>
            </div>
          );
        })}
      </div>

      <div className="h-fit rounded-sm border border-neutral-200 p-6">
        <h3 className="mb-4 font-serif text-xl text-charcoal">Order Summary</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-neutral-500">Subtotal</span><span>{formatCurrency(subtotal)}</span></div>
          <div className="flex justify-between">
            <span className="text-neutral-500">Shipping</span>
            <span>{shipping === 0 ? "Free" : formatCurrency(shipping)}</span>
          </div>
          <div className="flex justify-between border-t border-neutral-200 pt-2 font-semibold text-charcoal">
            <span>Total</span><span>{formatCurrency(total)}</span>
          </div>
        </div>
        <Link href="/checkout" className="btn-primary mt-6 w-full">Proceed to Checkout</Link>
      </div>
    </div>
  );
}
