"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import { Search, Heart, ShoppingBag, User, Menu, X, LayoutDashboard, LogOut } from "lucide-react";

const CATEGORIES = [
  { name: "Men's Perfumes", slug: "mens-perfumes" },
  { name: "Women's Perfumes", slug: "womens-perfumes" },
  { name: "Unisex Perfumes", slug: "unisex-perfumes" },
  { name: "Oud", slug: "oud" },
  { name: "Attar", slug: "attar" },
  { name: "Gift Sets", slug: "gift-sets" },
  { name: "Premium Collection", slug: "premium-collection" },
];

export function Navbar() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [cartCount, setCartCount] = useState(0);
  const [wishlistCount, setWishlistCount] = useState(0);

  useEffect(() => {
    if (status !== "authenticated") {
      setCartCount(0);
      setWishlistCount(0);
      return;
    }
    fetch("/api/cart")
      .then((r) => r.json())
      .then((d) => setCartCount(d.items?.reduce((n: number, i: any) => n + i.quantity, 0) || 0))
      .catch(() => {});
    fetch("/api/wishlist")
      .then((r) => r.json())
      .then((d) => setWishlistCount(d.items?.length || 0))
      .catch(() => {});
  }, [status]);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    router.push(`/products?search=${encodeURIComponent(searchQuery)}`);
  }

  return (
    <header className="sticky top-0 z-50 bg-charcoal text-ivory shadow-luxury">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 md:px-8">
        <Link href="/" className="font-serif text-2xl tracking-widest text-gold">
          MAISON <span className="text-ivory">CHARCOAL</span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm tracking-wide lg:flex">
          <Link href="/" className="hover:text-gold transition-colors">Home</Link>
          <Link href="/products" className="hover:text-gold transition-colors">Shop</Link>
          <div className="group relative">
            <button className="hover:text-gold transition-colors">Categories</button>
            <div className="invisible absolute left-0 top-full z-50 w-56 rounded-sm bg-charcoal-light py-2 opacity-0 shadow-luxury transition-all group-hover:visible group-hover:opacity-100">
              {CATEGORIES.map((c) => (
                <Link
                  key={c.slug}
                  href={`/products?category=${c.slug}`}
                  className="block px-4 py-2 text-sm hover:bg-charcoal-medium hover:text-gold"
                >
                  {c.name}
                </Link>
              ))}
            </div>
          </div>
        </nav>

        <form onSubmit={handleSearch} className="relative hidden flex-1 max-w-sm md:flex">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search perfumes..."
            className="w-full rounded-sm border border-charcoal-medium bg-charcoal-light px-4 py-2 text-sm text-ivory placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-gold"
          />
          <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-gold">
            <Search size={18} />
          </button>
        </form>

        <div className="flex items-center gap-4">
          <Link href="/wishlist" className="relative hidden sm:block hover:text-gold transition-colors">
            <Heart size={22} />
            {wishlistCount > 0 && (
              <span className="absolute -right-2 -top-2 flex h-4 w-4 items-center justify-center rounded-full bg-gold text-[10px] font-bold text-charcoal">
                {wishlistCount}
              </span>
            )}
          </Link>

          <Link href="/cart" className="relative hover:text-gold transition-colors">
            <ShoppingBag size={22} />
            {cartCount > 0 && (
              <span className="absolute -right-2 -top-2 flex h-4 w-4 items-center justify-center rounded-full bg-gold text-[10px] font-bold text-charcoal">
                {cartCount}
              </span>
            )}
          </Link>

          <div className="relative hidden sm:block">
            <button onClick={() => setAccountOpen((v) => !v)} className="hover:text-gold transition-colors">
              <User size={22} />
            </button>
            {accountOpen && (
              <div
                onMouseLeave={() => setAccountOpen(false)}
                className="absolute right-0 top-full mt-2 w-48 rounded-sm bg-charcoal-light py-2 shadow-luxury"
              >
                {session ? (
                  <>
                    <Link href="/dashboard" className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-charcoal-medium hover:text-gold">
                      <LayoutDashboard size={16} /> Dashboard
                    </Link>
                    {session.user.role === "ADMIN" && (
                      <Link href="/admin" className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-charcoal-medium hover:text-gold">
                        <LayoutDashboard size={16} /> Admin Panel
                      </Link>
                    )}
                    <button
                      onClick={() => signOut({ callbackUrl: "/" })}
                      className="flex w-full items-center gap-2 px-4 py-2 text-left text-sm hover:bg-charcoal-medium hover:text-gold"
                    >
                      <LogOut size={16} /> Logout
                    </button>
                  </>
                ) : (
                  <>
                    <Link href="/login" className="block px-4 py-2 text-sm hover:bg-charcoal-medium hover:text-gold">Login</Link>
                    <Link href="/register" className="block px-4 py-2 text-sm hover:bg-charcoal-medium hover:text-gold">Register</Link>
                  </>
                )}
              </div>
            )}
          </div>

          <button className="lg:hidden" onClick={() => setMobileOpen((v) => !v)}>
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="border-t border-charcoal-medium bg-charcoal-light px-4 py-4 lg:hidden">
          <form onSubmit={handleSearch} className="relative mb-4">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search perfumes..."
              className="w-full rounded-sm border border-charcoal-medium bg-charcoal px-4 py-2 text-sm text-ivory placeholder:text-neutral-400 focus:outline-none focus:ring-1 focus:ring-gold"
            />
          </form>
          <div className="flex flex-col gap-3 text-sm">
            <Link href="/" onClick={() => setMobileOpen(false)}>Home</Link>
            <Link href="/products" onClick={() => setMobileOpen(false)}>Shop</Link>
            {CATEGORIES.map((c) => (
              <Link key={c.slug} href={`/products?category=${c.slug}`} onClick={() => setMobileOpen(false)} className="pl-3 text-neutral-300">
                {c.name}
              </Link>
            ))}
            <Link href="/wishlist" onClick={() => setMobileOpen(false)}>Wishlist</Link>
            {session ? (
              <>
                <Link href="/dashboard" onClick={() => setMobileOpen(false)}>Dashboard</Link>
                {session.user.role === "ADMIN" && (
                  <Link href="/admin" onClick={() => setMobileOpen(false)}>Admin Panel</Link>
                )}
                <button onClick={() => signOut({ callbackUrl: "/" })} className="text-left">Logout</button>
              </>
            ) : (
              <>
                <Link href="/login" onClick={() => setMobileOpen(false)}>Login</Link>
                <Link href="/register" onClick={() => setMobileOpen(false)}>Register</Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
