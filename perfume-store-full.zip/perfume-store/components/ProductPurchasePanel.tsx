"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { Minus, Plus, ShoppingBag, Zap, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { WishlistButton } from "@/components/WishlistButton";

export function ProductPurchasePanel({
  productId,
  stock,
  isWishlisted,
}: {
  productId: string;
  stock: number;
  isWishlisted: boolean;
}) {
  const { status } = useSession();
  const router = useRouter();
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState<"cart" | "buy" | null>(null);

  function requireLogin() {
    toast.info("Please log in to continue");
    router.push("/login");
  }

  async function addToCart(): Promise<boolean> {
    const res = await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId, quantity }),
    });
    const data = await res.json();
    if (!res.ok) {
      toast.error(data.error || "Failed to add to cart");
      return false;
    }
    return true;
  }

  async function handleAddToCart() {
    if (status !== "authenticated") return requireLogin();
    setLoading("cart");
    const ok = await addToCart();
    setLoading(null);
    if (ok) {
      toast.success("Added to cart");
      router.refresh();
    }
  }

  async function handleBuyNow() {
    if (status !== "authenticated") return requireLogin();
    setLoading("buy");
    const ok = await addToCart();
    setLoading(null);
    if (ok) router.push("/checkout");
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <span className="text-sm font-medium text-charcoal">Quantity:</span>
        <div className="flex items-center rounded-sm border border-neutral-300">
          <button
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            className="p-2 hover:text-gold"
          >
            <Minus size={14} />
          </button>
          <span className="w-10 text-center text-sm">{quantity}</span>
          <button
            onClick={() => setQuantity((q) => Math.min(stock, q + 1))}
            className="p-2 hover:text-gold"
          >
            <Plus size={14} />
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <button onClick={handleAddToCart} disabled={loading !== null || stock === 0} className="btn-outline flex-1">
          {loading === "cart" ? <Loader2 size={16} className="animate-spin" /> : <ShoppingBag size={16} />}
          Add to Cart
        </button>
        <button onClick={handleBuyNow} disabled={loading !== null || stock === 0} className="btn-primary flex-1">
          {loading === "buy" ? <Loader2 size={16} className="animate-spin" /> : <Zap size={16} />}
          Buy Now
        </button>
        <WishlistButton
          productId={productId}
          initialWishlisted={isWishlisted}
          className="static h-12 w-12 border border-neutral-300 bg-transparent hover:bg-neutral-100"
        />
      </div>
    </div>
  );
}
