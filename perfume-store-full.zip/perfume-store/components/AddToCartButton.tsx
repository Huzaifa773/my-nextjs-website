"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { ShoppingBag, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export function AddToCartButton({
  productId,
  quantity = 1,
  outOfStock = false,
  className,
  full = false,
}: {
  productId: string;
  quantity?: number;
  outOfStock?: boolean;
  className?: string;
  full?: boolean;
}) {
  const { status } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function addToCart(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();

    if (status !== "authenticated") {
      toast.info("Please log in to add items to your cart");
      router.push("/login");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, quantity }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to add to cart");
      toast.success("Added to cart");
      router.refresh();
    } catch (err: any) {
      toast.error(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      onClick={addToCart}
      disabled={loading || outOfStock}
      className={cn(
        "btn-primary text-sm",
        full && "w-full",
        className
      )}
    >
      {loading ? <Loader2 size={16} className="animate-spin" /> : <ShoppingBag size={16} />}
      {outOfStock ? "Out of Stock" : "Add to Cart"}
    </button>
  );
}
