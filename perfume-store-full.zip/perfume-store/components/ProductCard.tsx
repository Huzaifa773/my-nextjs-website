import Link from "next/link";
import Image from "next/image";
import { formatCurrency } from "@/lib/utils";
import { WishlistButton } from "@/components/WishlistButton";
import { AddToCartButton } from "@/components/AddToCartButton";
import { StarRating } from "@/components/StarRating";

export interface ProductCardData {
  id: string;
  name: string;
  brand: string;
  price: number;
  discountPrice: number | null;
  stock: number;
  images: { url: string; altText: string | null }[];
  avgRating?: number;
  reviewCount?: number;
  isWishlisted?: boolean;
}

export function ProductCard({ product }: { product: ProductCardData }) {
  const image = product.images[0]?.url || "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=600&q=80";
  const hasDiscount = product.discountPrice != null && product.discountPrice < product.price;

  return (
    <Link href={`/products/${product.id}`} className="card-luxury group block overflow-hidden">
      <div className="relative aspect-square overflow-hidden bg-neutral-100">
        <Image
          src={image}
          alt={product.images[0]?.altText || product.name}
          fill
          sizes="(max-width: 768px) 50vw, 25vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {hasDiscount && (
          <span className="absolute left-3 top-3 rounded-sm bg-gold px-2 py-1 text-xs font-semibold text-charcoal">
            SALE
          </span>
        )}
        {product.stock === 0 && (
          <span className="absolute left-3 top-3 rounded-sm bg-charcoal px-2 py-1 text-xs font-semibold text-ivory">
            OUT OF STOCK
          </span>
        )}
        <WishlistButton
          productId={product.id}
          initialWishlisted={product.isWishlisted}
          className="absolute right-3 top-3"
        />
      </div>

      <div className="space-y-1 p-4">
        <p className="text-xs uppercase tracking-wide text-neutral-500">{product.brand}</p>
        <h3 className="font-serif text-lg text-charcoal">{product.name}</h3>
        {typeof product.avgRating === "number" && product.reviewCount ? (
          <StarRating rating={product.avgRating} count={product.reviewCount} />
        ) : null}
        <div className="flex items-center gap-2 pt-1">
          <span className="font-semibold text-charcoal">
            {formatCurrency(hasDiscount ? product.discountPrice! : product.price)}
          </span>
          {hasDiscount && (
            <span className="text-sm text-neutral-400 line-through">{formatCurrency(product.price)}</span>
          )}
        </div>
        <div className="pt-2">
          <AddToCartButton productId={product.id} outOfStock={product.stock === 0} full />
        </div>
      </div>
    </Link>
  );
}
